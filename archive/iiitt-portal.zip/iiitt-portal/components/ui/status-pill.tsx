import type { ComplianceStatus } from "@/lib/attendance/calc";

const label: Record<ComplianceStatus, string> = {
  compliant: "Meets requirement",
  below_threshold: "Below requirement",
  no_data: "No sessions yet",
};

const tone: Record<ComplianceStatus, string> = {
  compliant: "border-accent/40 text-accent",
  below_threshold: "border-risk/50 text-risk",
  no_data: "border-line text-muted",
};

/** Status is conveyed by text, not colour alone. */
export function StatusPill({ status }: { status: ComplianceStatus }) {
  return (
    <span className={`inline-flex rounded-full border px-2.5 py-0.5 text-xs font-medium ${tone[status]}`}>
      {label[status]}
    </span>
  );
}
