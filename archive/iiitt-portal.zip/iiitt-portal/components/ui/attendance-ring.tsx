import type { ComplianceStatus } from "@/lib/attendance/calc";
import { formatPercent } from "@/lib/attendance/calc";

export function AttendanceRing({
  percentage,
  status,
  size = 72,
}: {
  percentage: number | null;
  status: ComplianceStatus;
  size?: number;
}) {
  const stroke = 6;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const filled = percentage === null ? 0 : Math.min(percentage, 100) / 100;
  const color = status === "below_threshold" ? "stroke-risk" : "stroke-accent";

  return (
    <div
      className="relative shrink-0"
      style={{ width: size, height: size }}
      role="img"
      aria-label={`Attendance ${formatPercent(percentage)}`}
    >
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} className="stroke-line" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${circ * filled} ${circ}`}
          className={color}
        />
      </svg>
      <span className="absolute inset-0 grid place-items-center text-sm font-semibold tabular-nums">
        {formatPercent(percentage)}
      </span>
    </div>
  );
}
