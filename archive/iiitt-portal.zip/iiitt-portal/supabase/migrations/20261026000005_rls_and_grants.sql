-- Migration 5: Row Level Security and explicit grants. Nothing is reachable without both.

alter table public.branches enable row level security;
alter table public.batches enable row level security;
alter table public.sections enable row level security;
alter table public.approved_identities enable row level security;
alter table public.students enable row level security;
alter table public.lecturers enable row level security;
alter table public.courses enable row level security;
alter table public.course_offerings enable row level security;
alter table public.lecturer_assignments enable row level security;
alter table public.enrollments enable row level security;
alter table public.class_sessions enable row level security;
alter table public.attendance_records enable row level security;
alter table public.attendance_audit enable row level security;
alter table public.attendance_policy enable row level security;
alter table public.roster_imports enable row level security;
alter table public.roster_import_rows enable row level security;

-- Admin-only writes on reference/identity tables.
do $$
declare t text;
begin
  foreach t in array array['branches','batches','sections','courses','approved_identities','students',
                           'lecturers','course_offerings','lecturer_assignments','enrollments'] loop
    execute format('create policy %I on public.%I for insert to authenticated with check ((select private.is_admin()))', t || '_admin_insert', t);
    execute format('create policy %I on public.%I for update to authenticated using ((select private.is_admin())) with check ((select private.is_admin()))', t || '_admin_update', t);
    execute format('create policy %I on public.%I for delete to authenticated using ((select private.is_admin()))', t || '_admin_delete', t);
  end loop;
end $$;

-- Non-sensitive reference data: readable by any signed-in, approved user.
create policy branches_select on public.branches for select to authenticated using ((select private.current_identity_id()) is not null);
create policy batches_select on public.batches for select to authenticated using ((select private.current_identity_id()) is not null);
create policy sections_select on public.sections for select to authenticated using ((select private.current_identity_id()) is not null);
create policy courses_select on public.courses for select to authenticated using ((select private.current_identity_id()) is not null);

create policy approved_identities_select on public.approved_identities for select to authenticated
  using (auth_user_id = (select auth.uid()) or (select private.is_admin()));

create policy students_select on public.students for select to authenticated
  using (id = (select private.current_student_id()) or (select private.is_admin())
         or (select private.lecturer_teaches_student(id)));

create policy lecturers_select on public.lecturers for select to authenticated
  using (id = (select private.current_lecturer_id()) or (select private.is_admin()));

create policy course_offerings_select on public.course_offerings for select to authenticated
  using ((select private.is_admin()) or (select private.is_assigned(id)) or (select private.is_enrolled(id)));

create policy lecturer_assignments_select on public.lecturer_assignments for select to authenticated
  using ((select private.is_admin()) or lecturer_id = (select private.current_lecturer_id()));

create policy enrollments_select on public.enrollments for select to authenticated
  using ((select private.is_admin()) or student_id = (select private.current_student_id())
         or (select private.is_assigned(offering_id)));

-- Sessions: assigned lecturers create/schedule/cancel; enrolled students read.
create policy class_sessions_select on public.class_sessions for select to authenticated
  using ((select private.is_admin()) or (select private.is_assigned(offering_id)) or (select private.is_enrolled(offering_id)));
create policy class_sessions_insert on public.class_sessions for insert to authenticated
  with check ((select private.is_admin())
              or ((select private.is_assigned(offering_id)) and created_by = (select private.current_lecturer_id())));
create policy class_sessions_update on public.class_sessions for update to authenticated
  using ((select private.is_admin()) or ((select private.is_assigned(offering_id)) and state = 'scheduled'))
  with check ((select private.is_admin()) or (select private.is_assigned(offering_id)));
create policy class_sessions_delete on public.class_sessions for delete to authenticated
  using ((select private.is_admin()) or ((select private.is_assigned(offering_id)) and state = 'scheduled'));

-- Records: students read their own; assigned lecturers read their sessions and insert only while
-- the session is still scheduled. No update/delete policy and no UPDATE/DELETE grant exist for
-- anyone: corrections wait for an agreed workflow.
create policy attendance_records_select on public.attendance_records for select to authenticated
  using (student_id = (select private.current_student_id())
         or (select private.is_assigned(offering_id)) or (select private.is_admin()));
create policy attendance_records_insert on public.attendance_records for insert to authenticated
  with check ((select private.is_assigned(offering_id))
              and marked_by = (select private.current_lecturer_id())
              and exists (select 1 from public.class_sessions s where s.id = session_id and s.state = 'scheduled'));

create policy attendance_audit_select on public.attendance_audit for select to authenticated
  using ((select private.is_admin()));

create policy attendance_policy_select on public.attendance_policy for select to authenticated using (true);
create policy attendance_policy_update on public.attendance_policy for update to authenticated
  using ((select private.is_admin())) with check ((select private.is_admin()));

create policy roster_imports_admin on public.roster_imports for all to authenticated
  using ((select private.is_admin())) with check ((select private.is_admin()));
create policy roster_import_rows_admin on public.roster_import_rows for all to authenticated
  using ((select private.is_admin())) with check ((select private.is_admin()));

-- ---------------------------------------------------------------- grants (anon gets nothing)
grant select on public.branches, public.batches, public.sections, public.courses,
  public.approved_identities, public.students, public.lecturers, public.course_offerings,
  public.lecturer_assignments, public.enrollments, public.class_sessions, public.attendance_records,
  public.attendance_audit, public.attendance_policy, public.roster_imports, public.roster_import_rows,
  public.student_course_attendance
  to authenticated;

grant insert, update, delete on public.branches, public.batches, public.sections, public.courses,
  public.approved_identities, public.students, public.lecturers, public.course_offerings,
  public.lecturer_assignments, public.enrollments, public.roster_imports, public.roster_import_rows
  to authenticated;

-- Column-level grants: lecturers can never set who submitted, state history, or the offering.
grant insert (offering_id, session_date, start_time, end_time, created_by, client_token)
  on public.class_sessions to authenticated;
grant update (session_date, start_time, end_time, state, cancel_reason)
  on public.class_sessions to authenticated;
grant delete on public.class_sessions to authenticated;
grant insert (session_id, offering_id, student_id, mark, marked_by)
  on public.attendance_records to authenticated;
grant update (threshold_percent) on public.attendance_policy to authenticated;

-- service_role (server-only admin client): only the tables roster import / bootstrap needs.
grant select, insert, update, delete on public.approved_identities, public.students, public.lecturers,
  public.branches, public.batches, public.sections, public.enrollments,
  public.roster_imports, public.roster_import_rows to service_role;

-- Functions: revoke the implicit PUBLIC execute, then grant narrowly.
revoke all on all functions in schema private from public, anon;
grant usage on schema private to authenticated;
grant execute on all functions in schema private to authenticated;

revoke all on function public.submit_session_attendance(uuid, jsonb) from public, anon;
revoke all on function public.cancel_session(uuid, text) from public, anon;
revoke all on function public.enroll_section_in_offering(uuid) from public, anon;
grant execute on function public.submit_session_attendance(uuid, jsonb) to authenticated;
grant execute on function public.cancel_session(uuid, text) to authenticated;
grant execute on function public.enroll_section_in_offering(uuid) to authenticated;
