-- Migration 3: sessions, attendance records, audit, policy.

create table public.class_sessions (
  id uuid primary key default gen_random_uuid(),
  offering_id uuid not null references public.course_offerings (id),
  session_date date not null,
  start_time time not null,
  end_time time not null,
  state public.session_state not null default 'scheduled',
  created_by uuid references public.lecturers (id),
  client_token uuid,                       -- idempotency key so a retried "add session" never duplicates
  submitted_by uuid references public.lecturers (id),
  submitted_at timestamptz,
  cancelled_by uuid references public.lecturers (id),
  cancelled_at timestamptz,
  cancel_reason text,
  created_at timestamptz not null default now(),
  check (end_time > start_time),
  check ((state = 'completed') = (submitted_at is not null)),
  check ((state = 'cancelled') = (cancelled_at is not null)),
  unique (id, offering_id),
  unique (created_by, client_token),
  -- Two classes of one subject on one day are fine, but they may not overlap in time.
  -- This blocks accidental duplicates while allowing legitimate back-to-back classes.
  -- Cancelled sessions are ignored so a replacement can take the slot.
  constraint class_sessions_no_overlap exclude using gist (
    offering_id extensions.gist_uuid_ops with =,
    tsrange(session_date + start_time, session_date + end_time) with &&
  ) where (state <> 'cancelled')
);
create index class_sessions_offering_date_idx on public.class_sessions (offering_id, session_date);

create table public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null,
  offering_id uuid not null,
  student_id uuid not null,
  mark public.attendance_mark not null,
  marked_by uuid references public.lecturers (id),
  marked_at timestamptz not null default now(),
  unique (session_id, student_id),         -- one record per student per session
  foreign key (session_id, offering_id) references public.class_sessions (id, offering_id),
  foreign key (offering_id, student_id) references public.enrollments (offering_id, student_id)
);
create index attendance_records_student_idx on public.attendance_records (student_id);

create table public.attendance_audit (
  id bigint generated always as identity primary key,
  record_id uuid not null,
  session_id uuid not null,
  student_id uuid not null,
  action text not null check (action in ('insert', 'update', 'delete')),
  old_mark public.attendance_mark,
  new_mark public.attendance_mark,
  actor_auth_id uuid,
  reason text,
  at timestamptz not null default now()
);

-- Single-row policy table. Threshold is configurable; 75 is the currently confirmed value.
create table public.attendance_policy (
  id boolean primary key default true check (id),
  threshold_percent numeric(5, 2) not null default 75 check (threshold_percent between 0 and 100)
);
insert into public.attendance_policy default values;
