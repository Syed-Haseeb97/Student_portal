-- Migration 2: reference data, approved identities, people, courses, assignments, enrollments.

create table public.branches (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code <> ''),   -- mapping lives in data, not code
  name text not null
);

create table public.batches (
  id uuid primary key default gen_random_uuid(),
  entry_year int not null unique check (entry_year between 2000 and 2100)
);

create table public.sections (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.batches (id),
  branch_id uuid not null references public.branches (id),
  name text not null,
  unique (batch_id, branch_id, name)
);

-- Source of truth for who may use the portal. A verified @iiitt.ac.in email alone grants nothing.
create table public.approved_identities (
  id uuid primary key default gen_random_uuid(),
  email text not null unique
    check (email ~ '^[a-z0-9._%+-]+@iiitt\.ac\.in$'),  -- lowercase, exact domain, no subdomains
  role public.user_role not null,
  status public.identity_status not null default 'active',
  auth_user_id uuid unique references auth.users (id) on delete set null,
  created_at timestamptz not null default now(),
  unique (id, role)
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  identity_id uuid not null unique,
  identity_role public.user_role not null default 'student' check (identity_role = 'student'),
  roll_number text not null unique check (roll_number <> ''),  -- text: keeps leading zeros
  full_name text not null,
  section_id uuid references public.sections (id),
  foreign key (identity_id, identity_role) references public.approved_identities (id, role)
);

create table public.lecturers (
  id uuid primary key default gen_random_uuid(),
  identity_id uuid not null unique,
  identity_role public.user_role not null default 'lecturer' check (identity_role = 'lecturer'),
  full_name text not null,
  foreign key (identity_id, identity_role) references public.approved_identities (id, role)
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null
);

-- An offering is one course taught to one section in one term.
create table public.course_offerings (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses (id),
  section_id uuid not null references public.sections (id),
  term text not null,
  unique (course_id, section_id, term)
);

-- Several lecturers may be assigned to one offering; each needs an explicit row.
create table public.lecturer_assignments (
  id uuid primary key default gen_random_uuid(),
  offering_id uuid not null references public.course_offerings (id),
  lecturer_id uuid not null references public.lecturers (id),
  created_at timestamptz not null default now(),
  unique (offering_id, lecturer_id)
);

-- Course enrollment is separate from section membership so electives can be added later.
create table public.enrollments (
  offering_id uuid not null references public.course_offerings (id),
  student_id uuid not null references public.students (id),
  enrolled_at timestamptz not null default now(),
  primary key (offering_id, student_id)
);
create index enrollments_student_idx on public.enrollments (student_id);
create index lecturer_assignments_lecturer_idx on public.lecturer_assignments (lecturer_id);
create index students_section_idx on public.students (section_id);

create table public.roster_imports (
  id uuid primary key default gen_random_uuid(),
  file_name text,
  status text not null default 'pending' check (status in ('pending', 'validated', 'applied', 'rejected')),
  created_by uuid references auth.users (id),
  created_at timestamptz not null default now()
);

create table public.roster_import_rows (
  id uuid primary key default gen_random_uuid(),
  import_id uuid not null references public.roster_imports (id) on delete cascade,
  row_number int not null,
  raw jsonb not null,
  status text not null default 'pending' check (status in ('pending', 'valid', 'invalid', 'applied')),
  errors jsonb,
  unique (import_id, row_number)
);
