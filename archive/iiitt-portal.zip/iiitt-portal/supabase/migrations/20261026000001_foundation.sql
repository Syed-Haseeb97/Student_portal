-- Migration 1: schemas, extensions, enums, and a lockdown of default Data API privileges.
-- Supabase is moving to "opt-in" Data API exposure; we do not depend on either default.
-- Every table below gets explicit GRANTs plus RLS in migration 5.

create schema if not exists private;          -- helper functions; NOT exposed through the Data API
create extension if not exists btree_gist with schema extensions;

alter default privileges in schema public revoke all on tables from anon, authenticated, service_role;
alter default privileges in schema public revoke all on sequences from anon, authenticated, service_role;
alter default privileges in schema public revoke execute on functions from anon, authenticated, service_role;

create type public.user_role as enum ('student', 'lecturer', 'admin');
create type public.identity_status as enum ('active', 'disabled');
create type public.session_state as enum ('scheduled', 'cancelled', 'completed');
create type public.attendance_mark as enum ('present', 'absent');
