-- Migration 4: authorization helpers, triggers, RPC functions, attendance view.
-- Helpers are SECURITY DEFINER (they must read identity tables that users cannot read directly),
-- pinned to an empty search_path, and live in the non-exposed `private` schema.

create function private.current_identity_id() returns uuid
language sql stable security definer set search_path = '' as $$
  select i.id from public.approved_identities i
  where i.auth_user_id = (select auth.uid()) and i.status = 'active'
$$;

create function private.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.approved_identities i
    where i.auth_user_id = (select auth.uid()) and i.status = 'active' and i.role = 'admin')
$$;

create function private.current_student_id() returns uuid
language sql stable security definer set search_path = '' as $$
  select s.id from public.students s
  join public.approved_identities i on i.id = s.identity_id
  where i.auth_user_id = (select auth.uid()) and i.status = 'active'
$$;

create function private.current_lecturer_id() returns uuid
language sql stable security definer set search_path = '' as $$
  select l.id from public.lecturers l
  join public.approved_identities i on i.id = l.identity_id
  where i.auth_user_id = (select auth.uid()) and i.status = 'active'
$$;

create function private.is_assigned(p_offering uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.lecturer_assignments a
    where a.offering_id = p_offering and a.lecturer_id = private.current_lecturer_id())
$$;

create function private.is_enrolled(p_offering uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.enrollments e
    where e.offering_id = p_offering and e.student_id = private.current_student_id())
$$;

create function private.lecturer_teaches_student(p_student uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.enrollments e
    join public.lecturer_assignments a on a.offering_id = e.offering_id
    where e.student_id = p_student and a.lecturer_id = private.current_lecturer_id())
$$;

-- Audit: every change to a record is logged by trigger, not by application code.
create function private.audit_attendance() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'DELETE' then
    insert into public.attendance_audit (record_id, session_id, student_id, action, old_mark, actor_auth_id)
    values (old.id, old.session_id, old.student_id, 'delete', old.mark, (select auth.uid()));
    return old;
  elsif tg_op = 'UPDATE' then
    insert into public.attendance_audit (record_id, session_id, student_id, action, old_mark, new_mark, actor_auth_id)
    values (new.id, new.session_id, new.student_id, 'update', old.mark, new.mark, (select auth.uid()));
    return new;
  else
    insert into public.attendance_audit (record_id, session_id, student_id, action, new_mark, actor_auth_id)
    values (new.id, new.session_id, new.student_id, 'insert', new.mark, (select auth.uid()));
    return new;
  end if;
end $$;

create trigger attendance_records_audit
after insert or update or delete on public.attendance_records
for each row execute function private.audit_attendance();

-- Session rules enforced in the database, so they hold no matter which client calls it:
--  * completed and cancelled are final (editing submitted attendance is NOT decided yet)
--  * a session can be completed only when every enrolled student has a record
--  * who submitted/cancelled and when is set here, never trusted from the client
create function private.guard_class_session_update() returns trigger
language plpgsql security definer set search_path = '' as $$
declare v_records bigint; v_roster bigint;
begin
  if old.state <> 'scheduled' then
    raise exception 'session is already %, it can no longer be changed', old.state using errcode = '22023';
  end if;
  if new.offering_id <> old.offering_id or new.created_by is distinct from old.created_by then
    raise exception 'offering and creator of a session cannot be changed' using errcode = '22023';
  end if;
  if new.state = 'completed' then
    select count(*) into v_records from public.attendance_records where session_id = new.id;
    select count(*) into v_roster from public.enrollments where offering_id = new.offering_id;
    if v_roster = 0 or v_records <> v_roster then
      raise exception 'attendance must be recorded for every student on the roster (% of %)', v_records, v_roster
        using errcode = '23514';
    end if;
    new.submitted_by := private.current_lecturer_id();
    new.submitted_at := now();
  elsif new.state = 'cancelled' then
    new.cancelled_by := private.current_lecturer_id();
    new.cancelled_at := now();
  end if;
  return new;
end $$;

create trigger class_sessions_guard
before update on public.class_sessions
for each row execute function private.guard_class_session_update();

-- Submit one session's attendance atomically. SECURITY INVOKER: RLS and the triggers above still apply.
create function public.submit_session_attendance(p_session_id uuid, p_marks jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare v_offering uuid; v_state public.session_state; v_lecturer uuid := private.current_lecturer_id();
begin
  if v_lecturer is null then
    raise exception 'only lecturers can submit attendance' using errcode = '42501';
  end if;
  select offering_id, state into v_offering, v_state from public.class_sessions where id = p_session_id;
  if not found then
    raise exception 'session not found or not permitted' using errcode = '42501';
  end if;
  if v_state <> 'scheduled' then
    raise exception 'session is already %', v_state using errcode = '22023';
  end if;
  perform 1 from public.class_sessions where id = p_session_id and state = 'scheduled' for update;
  if not found then
    raise exception 'session was already submitted or cancelled' using errcode = '22023';
  end if;
  if jsonb_typeof(p_marks) is distinct from 'array' then
    raise exception 'marks must be a JSON array of {student_id, mark}' using errcode = '22023';
  end if;

  insert into public.attendance_records (session_id, offering_id, student_id, mark, marked_by)
  select p_session_id, v_offering, (m ->> 'student_id')::uuid, (m ->> 'mark')::public.attendance_mark, v_lecturer
  from jsonb_array_elements(p_marks) as m;

  update public.class_sessions set state = 'completed' where id = p_session_id;
end $$;

create function public.cancel_session(p_session_id uuid, p_reason text default null)
returns void language plpgsql security invoker set search_path = '' as $$
begin
  update public.class_sessions set state = 'cancelled', cancel_reason = p_reason
  where id = p_session_id and state = 'scheduled';
  if not found then
    raise exception 'session not found, not permitted, or no longer scheduled' using errcode = '42501';
  end if;
end $$;

-- Enrol every student of the offering's section. Admin-only in practice (RLS blocks others).
create function public.enroll_section_in_offering(p_offering uuid)
returns integer language plpgsql security invoker set search_path = '' as $$
declare v_count integer;
begin
  insert into public.enrollments (offering_id, student_id)
  select o.id, s.id from public.course_offerings o
  join public.students s on s.section_id = o.section_id
  where o.id = p_offering
  on conflict do nothing;
  get diagnostics v_count = row_count;
  return v_count;
end $$;

-- Attendance per student PER COURSE OFFERING. There is deliberately no overall figure.
-- Only COMPLETED sessions count: cancelled and scheduled sessions never enter the denominator.
-- security_invoker => the caller's RLS applies (students see only themselves).
create view public.student_course_attendance with (security_invoker = true) as
select
  c.student_id,
  c.offering_id,
  c.course_id,
  c.attended,
  c.missed,
  c.unrecorded,
  c.attended + c.missed as total,
  case when c.attended + c.missed = 0 then null
       else c.attended * 100.0 / (c.attended + c.missed) end as percentage,
  case when c.attended + c.missed = 0 then 'no_data'
       when c.attended * 100 >= p.threshold_percent * (c.attended + c.missed) then 'compliant'
       else 'below_threshold' end::text as status
from (
  select e.student_id, e.offering_id, o.course_id,
    count(*) filter (where s.state = 'completed' and r.mark = 'present') as attended,
    count(*) filter (where s.state = 'completed' and r.mark = 'absent') as missed,
    count(*) filter (where s.state = 'completed' and r.id is null) as unrecorded
  from public.enrollments e
  join public.course_offerings o on o.id = e.offering_id
  left join public.class_sessions s on s.offering_id = e.offering_id
  left join public.attendance_records r on r.session_id = s.id and r.student_id = e.student_id
  group by e.student_id, e.offering_id, o.course_id
) c
cross join public.attendance_policy p;
