-- SYNTHETIC development data only. Local database only. Never run against production.
-- Names, emails and roll numbers are invented. The branch codes below are the examples
-- you gave and are NOT an authoritative mapping.

insert into auth.users (instance_id, id, aud, role, email, created_at, updated_at) values
  ('00000000-0000-0000-0000-000000000000', 'a0000000-0000-0000-0000-000000000001', 'authenticated', 'authenticated', 'demo.admin@iiitt.ac.in', now(), now()),
  ('00000000-0000-0000-0000-000000000000', 'a0000000-0000-0000-0000-000000000011', 'authenticated', 'authenticated', 'demo.lecturer1@iiitt.ac.in', now(), now()),
  ('00000000-0000-0000-0000-000000000000', 'a0000000-0000-0000-0000-000000000012', 'authenticated', 'authenticated', 'demo.lecturer2@iiitt.ac.in', now(), now()),
  ('00000000-0000-0000-0000-000000000000', 'a0000000-0000-0000-0000-000000000021', 'authenticated', 'authenticated', 'demo.student1@iiitt.ac.in', now(), now()),
  ('00000000-0000-0000-0000-000000000000', 'a0000000-0000-0000-0000-000000000022', 'authenticated', 'authenticated', 'demo.student2@iiitt.ac.in', now(), now()),
  ('00000000-0000-0000-0000-000000000000', 'a0000000-0000-0000-0000-000000000023', 'authenticated', 'authenticated', 'demo.student3@iiitt.ac.in', now(), now());

insert into public.branches (id, code, name) values
  ('e0000000-0000-0000-0000-000000000001', '11', 'CSE'),
  ('e0000000-0000-0000-0000-000000000002', '12', 'AI & DS'),
  ('e0000000-0000-0000-0000-000000000003', '13', 'ECE'),
  ('e0000000-0000-0000-0000-000000000004', '14', 'VLSI');
insert into public.batches (id, entry_year) values ('e1000000-0000-0000-0000-000000000001', 2026);
insert into public.sections (id, batch_id, branch_id, name) values
  ('e2000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'A');

insert into public.approved_identities (id, email, role, auth_user_id) values
  ('b0000000-0000-0000-0000-000000000001', 'demo.admin@iiitt.ac.in', 'admin', 'a0000000-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000011', 'demo.lecturer1@iiitt.ac.in', 'lecturer', 'a0000000-0000-0000-0000-000000000011'),
  ('b0000000-0000-0000-0000-000000000012', 'demo.lecturer2@iiitt.ac.in', 'lecturer', 'a0000000-0000-0000-0000-000000000012'),
  ('b0000000-0000-0000-0000-000000000021', 'demo.student1@iiitt.ac.in', 'student', 'a0000000-0000-0000-0000-000000000021'),
  ('b0000000-0000-0000-0000-000000000022', 'demo.student2@iiitt.ac.in', 'student', 'a0000000-0000-0000-0000-000000000022'),
  ('b0000000-0000-0000-0000-000000000023', 'demo.student3@iiitt.ac.in', 'student', 'a0000000-0000-0000-0000-000000000023');

insert into public.lecturers (id, identity_id, full_name) values
  ('c0000000-0000-0000-0000-000000000011', 'b0000000-0000-0000-0000-000000000011', 'Demo Lecturer One'),
  ('c0000000-0000-0000-0000-000000000012', 'b0000000-0000-0000-0000-000000000012', 'Demo Lecturer Two');
insert into public.students (id, identity_id, roll_number, full_name, section_id) values
  ('d0000000-0000-0000-0000-000000000021', 'b0000000-0000-0000-0000-000000000021', 'DEMO-0001', 'Demo Student One', 'e2000000-0000-0000-0000-000000000001'),
  ('d0000000-0000-0000-0000-000000000022', 'b0000000-0000-0000-0000-000000000022', 'DEMO-0002', 'Demo Student Two', 'e2000000-0000-0000-0000-000000000001'),
  ('d0000000-0000-0000-0000-000000000023', 'b0000000-0000-0000-0000-000000000023', 'DEMO-0003', 'Demo Student Three', 'e2000000-0000-0000-0000-000000000001');

insert into public.courses (id, code, name) values
  ('e3000000-0000-0000-0000-000000000001', 'MATH101', 'Mathematics'),
  ('e3000000-0000-0000-0000-000000000002', 'PHY101', 'Physics'),
  ('e3000000-0000-0000-0000-000000000003', 'PROG101', 'Programming');
insert into public.course_offerings (id, course_id, section_id, term) values
  ('f0000000-0000-0000-0000-000000000001', 'e3000000-0000-0000-0000-000000000001', 'e2000000-0000-0000-0000-000000000001', '2026-ODD'),
  ('f0000000-0000-0000-0000-000000000002', 'e3000000-0000-0000-0000-000000000002', 'e2000000-0000-0000-0000-000000000001', '2026-ODD'),
  ('f0000000-0000-0000-0000-000000000003', 'e3000000-0000-0000-0000-000000000003', 'e2000000-0000-0000-0000-000000000001', '2026-ODD');
insert into public.lecturer_assignments (offering_id, lecturer_id) values
  ('f0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000011'),
  ('f0000000-0000-0000-0000-000000000003', 'c0000000-0000-0000-0000-000000000011'),
  ('f0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000012'),
  ('f0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000012');  -- co-lecturer on Mathematics

select public.enroll_section_in_offering(id) from public.course_offerings;

-- History: 8 completed sessions per course. Student 1 is at 100% in Maths, 62.5% in Physics.
do $$
declare o record; i int; v_sid uuid;
begin
  for o in select id from public.course_offerings loop
    for i in 1..8 loop
      insert into public.class_sessions (offering_id, session_date, start_time, end_time)
      values (o.id, current_date - (i * 2), '09:00', '10:00') returning id into v_sid;
      insert into public.attendance_records (session_id, offering_id, student_id, mark)
      select v_sid, o.id, e.student_id,
        (case when o.id = 'f0000000-0000-0000-0000-000000000002'
                   and e.student_id = 'd0000000-0000-0000-0000-000000000021' and i > 5
              then 'absent' else 'present' end)::public.attendance_mark
      from public.enrollments e where e.offering_id = o.id;
      update public.class_sessions set state = 'completed' where id = v_sid;
    end loop;
  end loop;
end $$;
