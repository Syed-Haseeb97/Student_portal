-- pgTAP tests. Run with: npx supabase test db   (needs Docker; see README)
-- Self-contained: builds its own synthetic fixtures inside a transaction that is rolled back.
-- Fixture ids use a "1000000" marker so they never collide with seed.sql data.
-- Statements under test run as the `authenticated` role with a chosen user's JWT claims
-- (tests.scalar_as / tests.exec_as), so RLS, grants and triggers are genuinely exercised.
begin;
select no_plan();

create schema tests;
grant usage on schema tests to authenticated;

create function tests.id(p text, n int) returns uuid language sql immutable as $$
  select (p || '1000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid $$;
create function tests.sid(n int) returns uuid language sql stable security definer as $$
  select id from public.class_sessions where client_token = tests.id('9', n) $$;
grant execute on function tests.id(text, int), tests.sid(int) to authenticated;

create function tests.scalar_as(p_uid uuid, p_sql text) returns text language plpgsql as $$
declare v text;
begin
  perform set_config('request.jwt.claims', json_build_object('sub', p_uid, 'role', 'authenticated')::text, true);
  set local role authenticated;
  execute p_sql into v;
  reset role;
  return v;
end $$;

create function tests.exec_as(p_uid uuid, p_sql text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', p_uid, 'role', 'authenticated')::text, true);
  set local role authenticated;
  execute p_sql;
  reset role;
end $$;

create function tests.new_session_sql(p_n int, p_offering uuid, p_days int, p_start time, p_end time, p_creator uuid)
returns text language sql as $$
  select format($f$ insert into public.class_sessions (offering_id, session_date, start_time, end_time, created_by, client_token)
                    values (%L, current_date + %s, %L, %L, %L, tests.id('9', %s)) $f$,
                p_offering, p_days, p_start, p_end, p_creator, p_n) $$;

create function tests.mk(p_student int, p_mark text) returns jsonb language sql as $$
  select jsonb_build_object('student_id', tests.id('d', p_student), 'mark', p_mark) $$;

create function tests.submit_sql(p_n int, p_marks jsonb) returns text language sql as $$
  select format('select public.submit_session_attendance(tests.sid(%s), %L::jsonb)', p_n, p_marks::text) $$;

create function tests.seed_sessions(p_offering uuid, p_total int, p_st1_present int, p_offset int)
returns void language plpgsql as $$
declare i int; v_sid uuid;
begin
  for i in 1..p_total loop
    insert into public.class_sessions (offering_id, session_date, start_time, end_time)
    values (p_offering, current_date - p_offset - i, '09:00', '10:00') returning id into v_sid;
    insert into public.attendance_records (session_id, offering_id, student_id, mark) values
      (v_sid, p_offering, tests.id('d', 21),
       (case when i <= p_st1_present then 'present' else 'absent' end)::public.attendance_mark),
      (v_sid, p_offering, tests.id('d', 22), 'present');
    update public.class_sessions set state = 'completed' where id = v_sid;
  end loop;
end $$;

-- ============================================================ fixtures (as postgres)
-- auth users: a1 admin | a11,a12,a13 lecturers | a21,a22,a23 students | a99 signed in but NOT on the roster
insert into auth.users (instance_id, id, aud, role, email, created_at, updated_at)
select '00000000-0000-0000-0000-000000000000', tests.id('a', n), 'authenticated', 'authenticated',
       'fixture' || n || '@iiitt.ac.in', now(), now()
from unnest(array[1, 11, 12, 13, 21, 22, 23, 99]) as n;

insert into public.branches (id, code, name) values (tests.id('e', 1), '91', 'Test branch');
insert into public.batches (id, entry_year) values (tests.id('1', 1), 2099);
insert into public.sections (id, batch_id, branch_id, name) values
  (tests.id('2', 1), tests.id('1', 1), tests.id('e', 1), 'T1'),
  (tests.id('2', 2), tests.id('1', 1), tests.id('e', 1), 'T2');

insert into public.approved_identities (id, email, role, auth_user_id) values
  (tests.id('b', 1),  'fixture1@iiitt.ac.in',  'admin',    tests.id('a', 1)),
  (tests.id('b', 11), 'fixture11@iiitt.ac.in', 'lecturer', tests.id('a', 11)),
  (tests.id('b', 12), 'fixture12@iiitt.ac.in', 'lecturer', tests.id('a', 12)),
  (tests.id('b', 13), 'fixture13@iiitt.ac.in', 'lecturer', tests.id('a', 13)),
  (tests.id('b', 21), 'fixture21@iiitt.ac.in', 'student',  tests.id('a', 21)),
  (tests.id('b', 22), 'fixture22@iiitt.ac.in', 'student',  tests.id('a', 22)),
  (tests.id('b', 23), 'fixture23@iiitt.ac.in', 'student',  tests.id('a', 23));

insert into public.lecturers (id, identity_id, full_name) values
  (tests.id('c', 11), tests.id('b', 11), 'Lecturer 1'),
  (tests.id('c', 12), tests.id('b', 12), 'Lecturer 2'),
  (tests.id('c', 13), tests.id('b', 13), 'Lecturer 3');
insert into public.students (id, identity_id, roll_number, full_name, section_id) values
  (tests.id('d', 21), tests.id('b', 21), 'T-0001', 'Student 1', tests.id('2', 1)),
  (tests.id('d', 22), tests.id('b', 22), 'T-0002', 'Student 2', tests.id('2', 1)),
  (tests.id('d', 23), tests.id('b', 23), 'T-0003', 'Student 3', tests.id('2', 2));

insert into public.courses (id, code, name) values
  (tests.id('3', 1), 'TMATH', 'Test Mathematics'),
  (tests.id('3', 2), 'TPHY', 'Test Physics');
-- f1 = Maths/section1, f2 = Physics/section1, f3 = Maths/section2
insert into public.course_offerings (id, course_id, section_id, term) values
  (tests.id('f', 1), tests.id('3', 1), tests.id('2', 1), 'T1'),
  (tests.id('f', 2), tests.id('3', 2), tests.id('2', 1), 'T1'),
  (tests.id('f', 3), tests.id('3', 1), tests.id('2', 2), 'T1');
insert into public.lecturer_assignments (offering_id, lecturer_id) values
  (tests.id('f', 1), tests.id('c', 11)),
  (tests.id('f', 2), tests.id('c', 11)),
  (tests.id('f', 2), tests.id('c', 12)),   -- two lecturers on Physics
  (tests.id('f', 3), tests.id('c', 13));

-- ============================================================ A. structure and grants
select is(public.enroll_section_in_offering(tests.id('f', 1)), 2, 'section roster enrols its 2 students in Maths');
select is(public.enroll_section_in_offering(tests.id('f', 2)), 2, 'section roster enrols its 2 students in Physics');
select is(public.enroll_section_in_offering(tests.id('f', 3)), 1, 'other section enrols its 1 student');
select is(public.enroll_section_in_offering(tests.id('f', 1)), 0, 'enrolling twice adds nothing');

select is_empty($$ select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
                   where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity $$,
                'RLS is enabled on every public table');
select is_empty($$ select 1 from information_schema.role_table_grants
                   where table_schema = 'public' and grantee = 'anon' $$,
                'anon holds no privileges on public tables');
select ok(not has_any_column_privilege('authenticated', 'public.attendance_records', 'UPDATE'),
          'nobody can UPDATE attendance records through the API');
select ok(not has_table_privilege('authenticated', 'public.attendance_records', 'DELETE'),
          'nobody can DELETE attendance records through the API');
select ok(not has_table_privilege('service_role', 'public.attendance_records', 'SELECT'),
          'service_role is not granted attendance data');
select hasnt_column('public', 'student_course_attendance', 'overall_percentage', 'no overall percentage exists');

select throws_ok($$ insert into public.approved_identities (email, role) values ('x@iiitt.ac.in.evil.com', 'student') $$,
                 '23514', null, 'lookalike suffix domain rejected');
select throws_ok($$ insert into public.approved_identities (email, role) values ('x@mail.iiitt.ac.in', 'student') $$,
                 '23514', null, 'subdomain rejected');
select throws_ok($$ insert into public.approved_identities (email, role) values ('x@xiiitt.ac.in', 'student') $$,
                 '23514', null, 'lookalike prefix domain rejected');
select throws_ok($$ insert into public.approved_identities (email, role) values ('X@iiitt.ac.in', 'student') $$,
                 '23514', null, 'non-normalised (uppercase) email rejected');
select lives_ok($$ insert into public.approved_identities (email, role) values ('ok.person@iiitt.ac.in', 'student') $$,
                'exact institutional domain accepted');
select throws_ok($$ insert into public.students (identity_id, roll_number, full_name)
                    select id, 'T-9999', 'Wrong role' from public.approved_identities where email = 'fixture11@iiitt.ac.in' $$,
                 '23503', null, 'a lecturer identity cannot become a student');

-- ============================================================ B. identity and read isolation
select is(tests.scalar_as(tests.id('a', 21), 'select count(*) from public.students'), '1',
          'student sees only their own profile');
select is(tests.scalar_as(tests.id('a', 21), 'select count(*) from public.approved_identities'), '1',
          'student sees only their own identity row');
select is(tests.scalar_as(tests.id('a', 99), 'select count(*) from public.branches'), '0',
          'signed-in user who is not on the roster sees nothing');
select is(tests.scalar_as(tests.id('a', 99), 'select count(*) from public.course_offerings'), '0',
          'unrostered user sees no offerings');
select throws_ok($$ select tests.exec_as(tests.id('a', 21), $q$
                      insert into public.approved_identities (email, role) values ('self.signup@iiitt.ac.in', 'admin') $q$) $$,
                 '42501', null, 'student cannot self-register an identity');
select is(tests.scalar_as(tests.id('a', 21), $q$ with u as (update public.approved_identities set role = 'admin' returning 1)
                                                 select count(*) from u $q$), '0',
          'student cannot change a role (update affects no rows)');
select is(tests.scalar_as(tests.id('a', 11), $q$ with u as (update public.approved_identities set role = 'admin' returning 1)
                                                 select count(*) from u $q$), '0',
          'lecturer cannot change a role');
select is((select role from public.approved_identities where id = tests.id('b', 21)), 'student'::public.user_role,
          'student role is unchanged');
select throws_ok($$ select tests.exec_as(tests.id('a', 21), tests.new_session_sql(1, tests.id('f', 1), 0, '09:00', '10:00', null)) $$,
                 '42501', null, 'student cannot create a class session');
select is(tests.scalar_as(tests.id('a', 11), 'select count(*) from public.students'), '2',
          'lecturer sees only students on their own offerings');
select is(tests.scalar_as(tests.id('a', 13), 'select count(*) from public.students'), '1',
          'other lecturer sees only their own students');
select is(tests.scalar_as(tests.id('a', 11), 'select count(*) from public.approved_identities'), '1',
          'lecturer cannot read other identities');
select is(tests.scalar_as(tests.id('a', 1), $q$ select count(*) from public.students where roll_number like 'T-%' $q$), '3',
          'admin sees all students');

-- ============================================================ C. sessions and the submission workflow
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(1, tests.id('f', 1), 0, '09:00', '10:00', tests.id('c', 11))) $$,
                'assigned lecturer creates a session');
select throws_ok($$ select tests.exec_as(tests.id('a', 13), tests.new_session_sql(90, tests.id('f', 1), 0, '12:00', '13:00', tests.id('c', 13))) $$,
                 '42501', null, 'unassigned lecturer cannot create a session for that offering');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(91, tests.id('f', 1), 0, '09:30', '10:30', tests.id('c', 11))) $$,
                 '23P01', null, 'an overlapping duplicate session is rejected');
select lives_ok($$ select tests.exec_as(tests.id('a', 11),
                      tests.new_session_sql(1, tests.id('f', 1), 0, '09:00', '10:00', tests.id('c', 11))
                      || ' on conflict (created_by, client_token) do nothing') $$,
                'a retried create with the same token is a no-op');
select is((select count(*) from public.class_sessions where client_token = tests.id('9', 1)), 1::bigint,
          'the retry did not create a second session');
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(2, tests.id('f', 1), 0, '10:00', '11:00', tests.id('c', 11))) $$,
                'a second class of the same subject on the same day is allowed');
select isnt(tests.sid(1), tests.sid(2), 'the two same-day sessions are separate rows');
select is((select count(*) from public.class_sessions where offering_id = tests.id('f', 1) and session_date = current_date),
          2::bigint, 'two sessions exist for that subject today');

-- sessions 3..6 are prepared for the negative cases below
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(3, tests.id('f', 1), 1, '09:00', '10:00', tests.id('c', 11))) $$, 'session 3 created');
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(4, tests.id('f', 1), 2, '09:00', '10:00', tests.id('c', 11))) $$, 'session 4 created');
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(5, tests.id('f', 1), 3, '09:00', '10:00', tests.id('c', 11))) $$, 'session 5 created');
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(6, tests.id('f', 1), 4, '09:00', '10:00', tests.id('c', 11))) $$, 'session 6 created');

select throws_ok($$ select tests.exec_as(tests.id('a', 21), $q$ insert into public.attendance_records
                      (session_id, offering_id, student_id, mark) values (tests.sid(1), tests.id('f', 1), tests.id('d', 21), 'present') $q$) $$,
                 '42501', null, 'student cannot write attendance for themselves');
select throws_ok($$ select tests.exec_as(tests.id('a', 13), tests.submit_sql(1, jsonb_build_array(tests.mk(21, 'present'), tests.mk(22, 'present')))) $$,
                 '42501', null, 'unassigned lecturer cannot submit another offering''s session');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), tests.submit_sql(4, jsonb_build_array(tests.mk(21, 'present')))) $$,
                 '23514', null, 'submission must cover the whole roster');
select is((select state from public.class_sessions where id = tests.sid(4)), 'scheduled'::public.session_state,
          'a rejected submission leaves the session scheduled');
select is((select count(*) from public.attendance_records where session_id = tests.sid(4)), 0::bigint,
          'a rejected submission leaves no partial records');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), tests.submit_sql(5, jsonb_build_array(tests.mk(21, 'present'), tests.mk(23, 'present')))) $$,
                 '23503', null, 'a student not enrolled in the offering cannot be marked');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), 'update public.class_sessions set state = ''completed'' where id = tests.sid(6)') $$,
                 '23514', null, 'cannot mark a session completed without full attendance');

select lives_ok($$ select tests.exec_as(tests.id('a', 11), format('select public.cancel_session(tests.sid(3), %L)', 'holiday')) $$,
                'lecturer cancels a session');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), tests.submit_sql(3, jsonb_build_array(tests.mk(21, 'present'), tests.mk(22, 'present')))) $$,
                 '22023', null, 'attendance cannot be submitted for a cancelled session');

select is((select count(*) from public.attendance_records where session_id = tests.sid(1)), 0::bigint, 'no records before submission');
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.submit_sql(1, jsonb_build_array(tests.mk(21, 'present'), tests.mk(22, 'absent')))) $$,
                'lecturer submits session 1');
select is((select state from public.class_sessions where id = tests.sid(1)), 'completed'::public.session_state, 'session 1 is completed');
select is((select count(*) from public.attendance_records where session_id = tests.sid(1)), 2::bigint, 'session 1 has two records');
select is((select count(*) from public.attendance_audit where session_id = tests.sid(1) and action = 'insert'), 2::bigint,
          'each record was audited');
select is((select count(*) from public.attendance_records where session_id = tests.sid(2)), 0::bigint,
          'submitting session 1 created nothing in session 2');
select is((select state from public.class_sessions where id = tests.sid(2)), 'scheduled'::public.session_state,
          'session 2 is still scheduled');

select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.submit_sql(2, jsonb_build_array(tests.mk(21, 'absent'), tests.mk(22, 'present')))) $$,
                'lecturer submits session 2 independently');
select is((select mark from public.attendance_records where session_id = tests.sid(1) and student_id = tests.id('d', 21)),
          'present'::public.attendance_mark, 'session 1 mark for student 1 unchanged by session 2');
select is((select mark from public.attendance_records where session_id = tests.sid(1) and student_id = tests.id('d', 22)),
          'absent'::public.attendance_mark, 'session 1 mark for student 2 unchanged by session 2');
select is((select mark from public.attendance_records where session_id = tests.sid(2) and student_id = tests.id('d', 21)),
          'absent'::public.attendance_mark, 'session 2 holds its own marks');

select throws_ok($$ select tests.exec_as(tests.id('a', 11), tests.submit_sql(1, jsonb_build_array(tests.mk(21, 'absent'), tests.mk(22, 'absent')))) $$,
                 '22023', null, 'a submitted session cannot be submitted again');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), $q$ insert into public.attendance_records
                      (session_id, offering_id, student_id, mark, marked_by)
                      values (tests.sid(1), tests.id('f', 1), tests.id('d', 21), 'absent', tests.id('c', 11)) $q$) $$,
                 '42501', null, 'lecturer cannot add records to a completed session');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), $q$ update public.attendance_records set mark = 'present' $q$) $$,
                 '42501', null, 'lecturer cannot edit submitted attendance');
select throws_ok($$ select tests.exec_as(tests.id('a', 11), 'delete from public.attendance_records') $$,
                 '42501', null, 'lecturer cannot delete attendance');
select is(tests.scalar_as(tests.id('a', 11), $q$ with u as (update public.class_sessions set session_date = current_date + 30
                                                            where id = tests.sid(1) returning 1) select count(*) from u $q$), '0',
          'a completed session cannot be rescheduled');
select throws_ok($$ insert into public.attendance_records (session_id, offering_id, student_id, mark)
                    values (tests.sid(1), tests.id('f', 1), tests.id('d', 21), 'absent') $$,
                 '23505', null, 'database rejects a second record for the same student and session');

-- two lecturers on one offering: session 7 (Physics) submitted by the co-lecturer, not its creator
select lives_ok($$ select tests.exec_as(tests.id('a', 11), tests.new_session_sql(7, tests.id('f', 2), 0, '09:00', '10:00', tests.id('c', 11))) $$,
                'lecturer 1 creates a Physics session');
select lives_ok($$ select tests.exec_as(tests.id('a', 12), tests.submit_sql(7, jsonb_build_array(tests.mk(21, 'present'), tests.mk(22, 'present')))) $$,
                'co-assigned lecturer 2 submits it');
select is((select marked_by from public.attendance_records where session_id = tests.sid(7) and student_id = tests.id('d', 21)),
          tests.id('c', 12), 'records show who marked them');
select is(tests.scalar_as(tests.id('a', 12), $q$ select count(*) from public.class_sessions where offering_id = tests.id('f', 1) $q$), '0',
          'lecturer 2 cannot see Maths sessions they are not assigned to');

-- ============================================================ D. read access after submissions
select is(tests.scalar_as(tests.id('a', 21), 'select count(*) from public.attendance_records'), '3', 'student 1 sees their 3 records');
select is(tests.scalar_as(tests.id('a', 21), $q$ select count(*) from public.attendance_records where student_id <> tests.id('d', 21) $q$), '0',
          'student 1 sees none of student 2''s records');
select is(tests.scalar_as(tests.id('a', 23), 'select count(*) from public.attendance_records'), '0', 'student 3 sees none of section 1''s records');
select is(tests.scalar_as(tests.id('a', 13), $q$ select count(*) from public.attendance_records where offering_id = tests.id('f', 1) $q$), '0',
          'unassigned lecturer sees no records of another offering');
select is(tests.scalar_as(tests.id('a', 11), $q$ select count(*) from public.attendance_records where offering_id = tests.id('f', 1) $q$), '4',
          'assigned lecturer sees the records of their offering');
select is(tests.scalar_as(tests.id('a', 1), $q$ select count(*) from public.attendance_audit where session_id = tests.sid(1) $q$), '2', 'admin can read the audit log');
select is(tests.scalar_as(tests.id('a', 11), 'select count(*) from public.attendance_audit'), '0', 'lecturer cannot read the audit log');
select is(tests.scalar_as(tests.id('a', 21), 'select count(*) from public.attendance_audit'), '0', 'student cannot read the audit log');
select throws_ok($$ select tests.exec_as(tests.id('a', 1), $q$ insert into public.attendance_records
                      (session_id, offering_id, student_id, mark) values (tests.sid(2), tests.id('f', 1), tests.id('d', 21), 'present') $q$) $$,
                 '42501', null, 'admin has no direct write path to attendance records');

-- ============================================================ E. per-subject percentages
do $$ begin
  insert into public.course_offerings (id, course_id, section_id, term) values
    (tests.id('f', 4), tests.id('3', 1), tests.id('2', 1), 'T2'),   -- Maths
    (tests.id('f', 5), tests.id('3', 2), tests.id('2', 1), 'T2'),   -- Physics
    (tests.id('f', 6), tests.id('3', 1), tests.id('2', 1), 'T3');   -- Maths again, for the 75% boundary
  perform public.enroll_section_in_offering(tests.id('f', 4));
  perform public.enroll_section_in_offering(tests.id('f', 5));
  perform public.enroll_section_in_offering(tests.id('f', 6));
  perform tests.seed_sessions(tests.id('f', 4), 10, 9, 100);   -- student 1: 9 of 10 = 90%
  perform tests.seed_sessions(tests.id('f', 5), 10, 7, 200);   -- student 1: 7 of 10 = 70%
  perform tests.seed_sessions(tests.id('f', 6), 4, 3, 300);    -- student 1: 3 of 4 = exactly 75%
  -- sessions that must NOT count: two cancelled, one scheduled
  insert into public.class_sessions (offering_id, session_date, start_time, end_time) values
    (tests.id('f', 4), current_date + 10, '09:00', '10:00'),
    (tests.id('f', 4), current_date + 11, '09:00', '10:00'),
    (tests.id('f', 4), current_date + 12, '09:00', '10:00');
  update public.class_sessions set state = 'cancelled'
   where offering_id = tests.id('f', 4) and session_date in (current_date + 10, current_date + 11);
end $$;

select is(tests.scalar_as(tests.id('a', 21), $q$ select status from public.student_course_attendance where offering_id = tests.id('f', 4) $q$),
          'compliant', 'Maths at 90% is compliant');
select is(tests.scalar_as(tests.id('a', 21), $q$ select status from public.student_course_attendance where offering_id = tests.id('f', 5) $q$),
          'below_threshold', 'Physics at 70% is flagged');
select is(tests.scalar_as(tests.id('a', 21), $q$ select status from public.student_course_attendance where offering_id = tests.id('f', 6) $q$),
          'compliant', 'exactly 75% is compliant');
select is(tests.scalar_as(tests.id('a', 21), $q$ select attended || '/' || missed || '/' || total || '/' || unrecorded
                                                 from public.student_course_attendance where offering_id = tests.id('f', 4) $q$),
          '9/1/10/0', 'cancelled and scheduled sessions are excluded from every count');
select ok((select sum(attended) * 100.0 / sum(total) from public.student_course_attendance
            where student_id = tests.id('d', 21) and offering_id in (tests.id('f', 4), tests.id('f', 5))) > 75,
          'student 1 is above 75% overall across Maths and Physics ...');
select is(tests.scalar_as(tests.id('a', 21), $q$ select count(*) from public.student_course_attendance
                                                 where status = 'below_threshold' and offering_id in (tests.id('f', 4), tests.id('f', 5)) $q$),
          '1', '... yet Physics is still flagged on its own');
select is(tests.scalar_as(tests.id('a', 21), $q$ select count(*) from public.student_course_attendance where student_id <> tests.id('d', 21) $q$),
          '0', 'a student sees only their own attendance summary');

select is(tests.scalar_as(tests.id('a', 21), $q$ with u as (update public.attendance_policy set threshold_percent = 1 returning 1) select count(*) from u $q$),
          '0', 'a student cannot change the threshold');
select is(tests.scalar_as(tests.id('a', 1), $q$ with u as (update public.attendance_policy set threshold_percent = 65 returning 1) select count(*) from u $q$),
          '1', 'an admin can change the threshold');
select is(tests.scalar_as(tests.id('a', 21), $q$ select status from public.student_course_attendance where offering_id = tests.id('f', 5) $q$),
          'compliant', 'with a 65% threshold, 70% is compliant (threshold is configurable)');

select * from finish();
rollback;
