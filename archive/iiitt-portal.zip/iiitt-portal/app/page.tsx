import { Button } from "@/components/ui/button";
import { StatusPill } from "@/components/ui/status-pill";
import { AttendanceRing } from "@/components/ui/attendance-ring";
import { evaluate, formatPercent } from "@/lib/attendance/calc";

// Synthetic preview data only. Real data arrives from Supabase in later stages.
const preview = [
  { name: "Mathematics", attended: 9, total: 10 },
  { name: "Physics", attended: 7, total: 10 },
  { name: "Programming", attended: 9, total: 11 },
].map((c) => ({ ...c, ...evaluate(c.attended, c.total) }));

export default function Home() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col gap-8 px-5 py-10">
      <header className="space-y-2">
        <p className="font-mono text-xs uppercase tracking-widest text-indigo">IIIT Trichy</p>
        <h1 className="text-3xl font-semibold tracking-tight">Student Portal</h1>
        <p className="text-sm text-muted">Attendance, per subject. Sign-in arrives in Stage 4.</p>
        <Button disabled className="mt-2 w-full">Sign in with institute email</Button>
      </header>

      <section aria-labelledby="preview" className="space-y-3">
        <h2 id="preview" className="text-xs font-medium uppercase tracking-widest text-muted">
          Design preview · synthetic data
        </h2>
        <ul className="space-y-3">
          {preview.map((c) => (
            <li key={c.name} className="flex items-center gap-4 rounded-2xl border border-line bg-surface p-4">
              <AttendanceRing percentage={c.percentage} status={c.status} />
              <div className="min-w-0 flex-1 space-y-1.5">
                <p className="truncate font-medium">{c.name}</p>
                <p className="text-sm text-muted tabular-nums">
                  {c.attended} of {c.total} classes · {formatPercent(c.percentage)}
                </p>
                <StatusPill status={c.status} />
              </div>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
